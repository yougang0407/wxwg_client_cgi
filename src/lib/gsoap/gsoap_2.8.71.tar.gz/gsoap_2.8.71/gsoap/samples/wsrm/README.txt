
This application demonstrates server-side and client-side logic for services
based on WS-ReliableMessaging (and WS-Addressing).

For more details, please see wsrmdemo.h. Instructions about the demo are
included therein.
